str(airquality) #뉴욕의 공기 퀄리티 관련 데이터셋 로딩

head(airquality)
tail(airquality)

boxplot(airquality$Ozone, airquality$Wind, airquality$Temp) # 오존, 바람, 온도 에대한 boxplot 그림