print(head(airquality))
print((67+72+74+62+56+66)/6)
