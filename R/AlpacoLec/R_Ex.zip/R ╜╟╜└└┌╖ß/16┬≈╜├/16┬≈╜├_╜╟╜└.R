#12 차시 R 데이터 자료구조 실습 코드
age <- c(30, 33, 35, 30, 68, 33) # 나이 벡터 생성
job <- c("무직", "서비스", "관리직", "관리직", "은퇴", "관리직") # 직업 벡터 생성
marital <- c("결혼", "결혼", "미혼", "결혼", "사별", "결혼") # 결혼 유무 벡터 생성
balance <- c(1787, 4789, 1350, 1476, 4189, 3935) # 은행 잔고 벡터 생성
campaign <- c("휴대폰", "휴대폰", "휴대폰", "Unknown", "유선전화", "휴대폰") # 상담 매체 벡터 생성
y <- c(F, F, F, F, T, T) # 상담 결과 벡터 생성

result <- data.frame(age, job, marital, balance, campaign, y) #데이터 프레임 생성
print(result) #출력


#16 차시 R 변수, 함수, 패키지 실습 코드
age_mean <- mean(age)
balance_mean <- mean(balance)
print(age_mean)
print(balance_mean)

yToNum <- as.numeric(y)                                  # 상담 결과 벡터를 numeric 형식으로 형 변환
yCount <- sum(yToNum)                                   # sum: 벡터 값들의 총합 리턴
print(yCount)

#실습 문제

#string 패키지 설치/로딩
install.packages("stringr")
library(stringr)

job_new <- str_replace(job, "은퇴", "무직")      # "은퇴" 값을 "무직"으로 변경
print(job_new)                                   
marital_new <- str_replace(marital, "결혼", "T") # "결혼" 값을 "T"로 변경
print(marital_new)                               
marital_logical <- as.logical(marital_new)       # marital_new 벡터 logical로 강제 형변환
print(marital_logical)                           # character -> logical 로의 형변환 시, "T", "F"외의 값은 NA로 변환 됨
marital_logical[is.na(marital_logical)] = F      # NA값을 F로 변환
print(marital_logical)

result_new <- data.frame(age, job_new, marital_logical, balance, campaign, y)
print(result_new) #출력
