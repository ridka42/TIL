#22차시 실습 자료

#Q1
data <- read.csv('TravelMode.csv')

head(data)
dim(data)   # (840 10)

#Q2-1
choice <- data$choice
choice_yes_index <- which(choice == "yes")
choice_yes_index
actual_data <- data[choice_yes_index,]  #choice값이 yes인 행과, 그 행들의 모든 열로 이루어진 데이터 프레임
head(actual_data)


#Q2-2
processed_data <- actual_data[,c(-1, -2, -4)] # x, individual, choice 칼럼은 필요없으므로 제거
head(processed_data)
str(processed_data)

#Q3
print(mean(processed_data$wait))
print(mean(processed_data$vcost))
print(mean(processed_data$travel))
print(mean(processed_data$gcost))
print(mean(processed_data$income))

#Q4
table(processed_data$mode)
table(processed_data$size)

#Q5
mode_table <- table(processed_data$mode)
mode_names <- names(mode_table)
mode_numeric <- as.numeric(mode_table)
bus_selected_count <- mode_numeric[which(mode_names == "bus")]  #bus가 선택된 횟수 저장
bus_selected_rate <- bus_selected_count/ sum(mode_numeric)
print(bus_selected_rate) # 약 14.3%

#Q6
size_table <- table(processed_data$size)
size_names <- names(size_table)
size_numeric <- as.numeric(size_table)
solo_selected_count <- size_numeric[which(size_names == "1")]  #1인 가구 수 저장
size_selected_rate <- solo_selected_count/ sum(size_numeric)
print(size_selected_rate) # 약 54.3%
