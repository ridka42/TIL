#19차시 실습코드

#Q1
# min 직접 구현
data <- c(32, 45, 21, 10, 43)
min <- 99999999                       #충분히 큰 값으로 초기화
for( i in data){
  min <- ifelse( i < min, i, min)
}
print(min)

#Q2
data <- c(32, 45, 21, 10, 43)
for( i in data){
  if( i%%2 ==0 ) { #2의 배수라면
    print(TRUE)
  } else {
    print(FALSE)
  }
}


#Q3
# 홀수번째 값 sum 구현
data <- c(32, 45, 21, 10, 43)
sum <- 0                           # 홀수 자리 합 저장할 변수 초기화
i <- 1                              # 데이터 인덱스 나타냄
while( i <= length(data)){
  if( i %% 2 == 1 ) {         # 홀수 라면
    sum <- sum + data[i]
  } 
  i <- i+1
}


#Q4
airline <- c('아시아나항공', '에어부산', '에어프레미아', '에어서울', '제주항공', '진에어', '대한항공', '티웨이항공')
flight <- c(1575, 481, 124, 354, 1197, 793, 1670, 859)
result <- c()

i <- 1
while(i <= length(airline)){
  if(flight[i] > mean(flight)){
    result <- c(result, airline[i])
  }
  i <- i + 1
}
print(result)
