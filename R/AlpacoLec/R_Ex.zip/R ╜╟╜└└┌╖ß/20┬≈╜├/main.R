#20차시 실습자료
#main.R

source('airport.R', encoding = 'UTF-8')

airline <- get_airline()
print(airline)

flight <- get_flight()
print(flight)

passenger <- get_passenger()
print(passenger)

freight <- get_freight()
print(freight)

airport <- get_airport()
print(airport)

result17 <- upperAgvAirline_17()
result18 <- upperAgvAirline_18()
result19 <- upperAgvAirline_19()
print(result17)
print(result18)
print(result19)
